import React, { useState } from 'react';
import './App.css'; // Importa o arquivo de estilos CSS para o componente

// URL para o arquivo JSON que contém dados de previsão do tempo
const JSON_URL = '/weatherData.json';

function App() {
  // Define os estados do componente usando useState

  // Armazena o nome da cidade pesquisada
  const [city, setCity] = useState('');
  // Armazena as informações de previsão do tempo da cidade pesquisada
  const [weather, setWeather] = useState(null);
  // Armazena mensagens de erro, se houver
  const [error, setError] = useState(null);
  // Armazena os dados carregados do arquivo JSON
  const [data, setData] = useState(null);
  // Armazena o estado de carregamento (se os dados estão sendo carregados)
  const [isLoading, setIsLoading] = useState(false);

  // Função para carregar dados do JSON
  const fetchWeatherData = () => {
    setIsLoading(true); // Define o estado de carregamento como verdadeiro
    fetch(JSON_URL)
      .then(response => response.json()) // Converte a resposta em JSON
      .then(data => {
        setData(data); // Atualiza o estado com os dados do JSON
        const cityWeather = data[city]; // Obtém as informações da cidade do JSON
        if (cityWeather) {
          setWeather(cityWeather); // Atualiza o estado com as informações do tempo
          setError(null); // Limpa qualquer mensagem de erro
        } else {
          setWeather(null); // Limpa as informações do tempo
          setError('Cidade não encontrada'); // Define uma mensagem de erro se a cidade não estiver no JSON
        }
        setIsLoading(false); // Define o estado de carregamento como falso
      })
      .catch(() => {
        setWeather(null); // Limpa as informações do tempo
        setError('Erro ao carregar dados'); // Define uma mensagem de erro se houver problema na requisição
        setIsLoading(false); // Define o estado de carregamento como falso
      });
  };

  // Função para tratar o clique no botão de busca
  const handleSearch = () => {
    if (city) {
      fetchWeatherData(); // Chama a função para buscar os dados do tempo
    }
  };

  return (
    <div className="App"> {/* Container principal do componente */}
      <h1>Previsão do Tempo</h1> {/* Cabeçalho do aplicativo */}
      <input
        type="text"
        placeholder="Digite o nome da cidade"
        value={city} // Valor do campo de entrada controlado pelo estado da cidade
        onChange={(e) => setCity(e.target.value)} // Atualiza o estado da cidade quando o valor do campo muda
      />
      <button onClick={handleSearch}>Buscar</button> {/* Botão para acionar a busca */}
      {isLoading && <p>Carregando...</p>} {/* Exibe uma mensagem de carregamento se os dados estiverem sendo carregados */}
      {error && <p className="error">{error}</p>} {/* Exibe a mensagem de erro, se houver */}
      {weather && (
        <div className="weather-info"> {/* Container para as informações do tempo */}
          <h2>{city}</h2> {/* Nome da cidade */}
          <p>Temperatura: {weather.temperature}°C</p> {/* Temperatura atual */}
          <p>Condições: {weather.description}</p> {/* Descrição das condições climáticas */}
          <img
            src={`http://openweathermap.org/img/wn/${weather.icon}.png`} // URL do ícone do clima
            alt={weather.description} // Texto alternativo para o ícone
          />
        </div>
      )}
    </div>
  );
}

export default App; // Exporta o componente para uso em outras partes da aplicação
